#!/bin/bash
set -euo pipefail

sleep 5
apt-get update
apt-get install sudo curl unzip -y

# Begin AI Pack execution logic
SCRIPT_NAME="aipack_runner.sh"
LOGGER_NAME="aipack_runner"
APP_NAME="${AIPACK_NAME}"

log() {
  LEVEL="$1"
  FUNC="$2"
  LINE="$3"
  MSG="$4"
  TS=$(date '+%Y-%m-%d %H:%M:%S,%3N')
  printf '[%s|%s|%s|%s(%s)|%s.%s()] %s\n' "$TS" "$APP_NAME" "$LEVEL" "$SCRIPT_NAME" "$LINE" "$LOGGER_NAME" "$FUNC" "$MSG"
}

log_info() { log "INFO" "${FUNCNAME[0]}" "${BASH_LINENO[0]}" "$1"; }
log_error() { log "ERROR" "${FUNCNAME[0]}" "${BASH_LINENO[0]}" "$1"; }
error_exit() { log_error "$1"; exit 1; }

if [ -n "${_ALD_PREREQUISITE_INSTALL_FILENAME:-}" ]; then
  curl -H "Authorization: Bearer ${_ALD_SERVICE_TOKEN}" \
    -o "${_ALD_PREREQUISITE_INSTALL_FILENAME}" \
    "${_ALD_LOGIC_DOWNLOAD_API_URI}?pathname=${_ALD_LOGIC_PATH}/${_ALD_PREREQUISITE_INSTALL_FILENAME}" || error_exit "failed to download prerequisite install script"
  log_info "Executing ${_ALD_PREREQUISITE_INSTALL_FILENAME}..."
  
  chmod +x "${_ALD_PREREQUISITE_INSTALL_FILENAME}"
  
  log_info "User script content:"
  while IFS= read -r line; do log_info "  $line"; done < "${_ALD_PREREQUISITE_INSTALL_FILENAME}"

  log_info "Executing user script..."
  bash "${_ALD_PREREQUISITE_INSTALL_FILENAME}" || error_exit "user script failed"
fi

log_info "Downloading logic code..."
curl -H "Authorization: Bearer ${_ALD_SERVICE_TOKEN}" \
  -o "${_ALD_LOGIC_FILENAME}" \
  "${_ALD_LOGIC_DOWNLOAD_API_URI}?pathname=${_ALD_LOGIC_PATH}/${_ALD_LOGIC_FILENAME}" || error_exit "failed to download logic code"

log_info "Unzipping logic code..."
unzip -o "${_ALD_LOGIC_FILENAME}" -x "${_ALD_LOGIC_FILENAME}" || error_exit "failed to unzip logic code"

if [ -n "${_ALD_ENTRY_POINT:-}" ]; then
  log_info "Executing _ALD_ENTRY_POINT..."  
  
  log_info "User script content:"
  log_info "  ${_ALD_ENTRY_POINT}"

  log_info "Executing user script..."
  bash -c "${_ALD_ENTRY_POINT}" || error_exit "user script failed"
fi
